const sw_url = 'https://swapi.dev/api/people'
let list = [];
async function getstar(){
    const response = await fetch (sw_url);
    const data = await response.json();
    const {name} = data;
   // console.log(data);
   data.results.forEach(element =>  {
    const newPerson ={
        name:element.name,
        eye_color: element.eye_color,
        gender: element.gender

     }
   list.push(newPerson);
    }
   );
 showStarList(list);

}
function showStarList(list){
    const container=document.getElementById("people");
    container.innerHTML="";
    list.forEach(element =>{
        const item =document.createElement('li');
        if (element.gender==="n/a"){element.gender="droid";}
        item.innerHTML=`${element.name}, ${element.gender}, ${element.eye_color} eyes`;
        container.appendChild(item);
    });
}

getstar();
console.log(list);